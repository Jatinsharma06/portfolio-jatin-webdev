import React from 'react';
import { 
  Cloud, 
  Server, 
  Code, 
  GitBranch,
  Monitor,
  Shield,
  Mail,
  Phone,
  Linkedin,
  Github,
  Download,
  ChevronRight,
  Database,
  Settings,
  Layers
} from 'lucide-react';

function App() {
  const skills = [
    {
      category: "Cloud Platforms",
      icon: <Cloud className="w-6 h-6" />,
      items: ["AWS (EC2, S3, Lambda, RDS)", "Microsoft Azure", "Google Cloud Platform", "DigitalOcean"]
    },
    {
      category: "Containerization & Orchestration",
      icon: <Layers className="w-6 h-6" />,
      items: ["Docker", "Kubernetes", "Docker Compose", "Container Registry"]
    },
    {
      category: "CI/CD & Automation",
      icon: <GitBranch className="w-6 h-6" />,
      items: ["Jenkins", "GitHub Actions", "GitLab CI/CD", "Azure DevOps"]
    },
    {
      category: "Infrastructure as Code",
      icon: <Code className="w-6 h-6" />,
      items: ["Terraform", "AWS CloudFormation", "Ansible", "Pulumi"]
    },
    {
      category: "Monitoring & Logging",
      icon: <Monitor className="w-6 h-6" />,
      items: ["Prometheus", "Grafana", "ELK Stack", "CloudWatch", "Datadog"]
    },
    {
      category: "Operating Systems & Scripting",
      icon: <Server className="w-6 h-6" />,
      items: ["Linux (Ubuntu, CentOS)", "Windows Server", "Bash Scripting", "Python", "PowerShell"]
    },
    {
      category: "Database & Storage",
      icon: <Database className="w-6 h-6" />,
      items: ["MySQL", "PostgreSQL", "MongoDB", "Redis", "AWS RDS"]
    },
    {
      category: "Security & Networking",
      icon: <Shield className="w-6 h-6" />,
      items: ["VPC Configuration", "Security Groups", "SSL/TLS", "IAM", "Network Security"]
    }
  ];

  const projects = [
    {
      title: "Multi-Tier Web Application Deployment",
      description: "Deployed a scalable web application using Docker containers, implemented CI/CD pipeline with GitHub Actions, and managed infrastructure with Terraform on AWS.",
      technologies: ["AWS", "Docker", "Terraform", "GitHub Actions", "Nginx"],
      highlights: ["Auto-scaling configuration", "Zero-downtime deployment", "Infrastructure monitoring"]
    },
    {
      title: "Kubernetes Cluster Management",
      description: "Set up and managed a Kubernetes cluster for microservices deployment, implemented monitoring with Prometheus and Grafana, and automated deployments.",
      technologies: ["Kubernetes", "Docker", "Prometheus", "Grafana", "Helm"],
      highlights: ["Service mesh implementation", "Resource optimization", "Health monitoring"]
    },
    {
      title: "Automated Infrastructure Provisioning",
      description: "Created Infrastructure as Code using Terraform to provision AWS resources, implemented configuration management with Ansible, and set up monitoring solutions.",
      technologies: ["Terraform", "Ansible", "AWS", "CloudWatch", "Python"],
      highlights: ["Cost optimization", "Security compliance", "Automated backups"]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Settings className="w-8 h-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-800">DevOps Engineer</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#about" className="text-gray-600 hover:text-blue-600 transition-colors">About</a>
              <a href="#skills" className="text-gray-600 hover:text-blue-600 transition-colors">Skills</a>
              <a href="#projects" className="text-gray-600 hover:text-blue-600 transition-colors">Projects</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="mb-8">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-4">
              Hi, I'm <span className="text-blue-600">Jatin Sharma</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-6">
              Aspiring DevOps & Cloud Engineer
            </p>
            <p className="text-lg text-gray-500 max-w-3xl mx-auto leading-relaxed">
              Passionate about cloud technologies, automation, and building scalable infrastructure. 
              Seeking an entry-level position to contribute to innovative projects and grow in the DevOps field.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="#"
              onClick={(e) => {
                e.preventDefault();
                // Replace this URL with your actual resume download link
                const resumeUrl = "https://drive.google.com/file/d/1cjErV1urGUmbYmqtQTlCEAAQTz7I5bMd/view?usp=sharing";
                const link = document.createElement('a');
                link.href = resumeUrl;
                link.download = 'Jatin_Sharma_Resume.pdf';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 group"
            >
              <Download className="w-5 h-5" />
              <span>Download Resume</span>
            </a>
            <a href="#contact" className="border-2 border-blue-600 text-blue-600 px-8 py-3 rounded-lg hover:bg-blue-600 hover:text-white transition-colors flex items-center justify-center space-x-2">
              <span>Get In Touch</span>
              <ChevronRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-12">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Passionate About Cloud Innovation</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                As a recent graduate with a strong foundation in computer science and a passion for cloud technologies, 
                I'm eager to begin my career in DevOps engineering. Through hands-on projects and continuous learning, 
                I've developed skills in cloud platforms, containerization, and automation.
              </p>
              <p className="text-gray-600 leading-relaxed mb-6">
                I believe in the power of infrastructure as code, continuous integration, and the DevOps culture to 
                transform how we build and deploy applications. My goal is to contribute to creating reliable, 
                scalable, and secure systems.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">5+</div>
                  <div className="text-sm text-gray-600">Projects Completed</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">5</div>
                  <div className="text-sm text-gray-600">Cloud Certifications</div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-100 to-indigo-100 p-8 rounded-2xl">
              <h4 className="text-xl font-semibold text-gray-800 mb-4">Key Strengths</h4>
              <ul className="space-y-3">
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Strong problem-solving and analytical skills</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Quick learner with adaptability to new technologies</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Excellent communication and teamwork abilities</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Passionate about automation and efficiency</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Detail-oriented with focus on security best practices</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-4">Technical Skills</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Comprehensive skill set covering modern DevOps practices, cloud technologies, and automation tools
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {skills.map((skill, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                    {skill.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">{skill.category}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item, itemIndex) => (
                    <span key={itemIndex} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-blue-100 hover:text-blue-700 transition-colors">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-4">Featured Projects</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Hands-on projects demonstrating practical application of DevOps principles and cloud technologies
          </p>
          <div className="grid lg:grid-cols-1 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="bg-gradient-to-r from-white to-blue-50 rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow border border-blue-100">
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <h3 className="text-2xl font-semibold text-gray-800 mb-3">{project.title}</h3>
                    <p className="text-gray-600 leading-relaxed mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech, techIndex) => (
                        <span key={techIndex} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-blue-200">
                    <h4 className="font-semibold text-gray-800 mb-3">Key Highlights</h4>
                    <ul className="space-y-2">
                      {project.highlights.map((highlight, highlightIndex) => (
                        <li key={highlightIndex} className="flex items-center space-x-2 text-sm">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-600">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-gradient-to-br from-blue-900 to-indigo-900 text-white">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Let's Connect</h2>
          <p className="text-xl text-blue-100 mb-12 max-w-2xl mx-auto">
            Ready to start my DevOps journey and contribute to innovative projects. Let's discuss how I can add value to your team.
          </p>
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <a href="mailto:alex.johnson@email.com" className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-colors group">
              <Mail className="w-8 h-8 mx-auto mb-4 text-blue-300 group-hover:text-white transition-colors" />
              <h3 className="text-lg font-semibold mb-2">Email</h3>
              <p className="text-blue-100">jatinsharma61003@gmail.com</p>
            </a>
            <a href="tel:+1234567890" className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-colors group">
              <Phone className="w-8 h-8 mx-auto mb-4 text-blue-300 group-hover:text-white transition-colors" />
              <h3 className="text-lg font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">+91-9821972494</p>
            </a>
            <a href="https://www.linkedin.com/in/jatin-sharma-engineer/" className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-colors group">
              <Linkedin className="w-8 h-8 mx-auto mb-4 text-blue-300 group-hover:text-white transition-colors" />
              <h3 className="text-lg font-semibold mb-2">LinkedIn</h3>
              <p className="text-blue-100">linkedin.com/in/jatin-sharma-engineer</p>
            </a>
          </div>
          <div className="flex justify-center space-x-6">
            <a href="https://github.com/Jatinsharma06" className="bg-white/10 backdrop-blur-sm p-3 rounded-full hover:bg-white/20 transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://www.linkedin.com/in/jatin-sharma-engineer" className="bg-white/10 backdrop-blur-sm p-3 rounded-full hover:bg-white/20 transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p>&copy; 2024 Jatin Sharma. All rights reserved.</p>
          <p className="mt-2 text-sm">Built with passion for DevOps and Cloud Technologies</p>
        </div>
      </footer>
    </div>
  );
}

export default App;